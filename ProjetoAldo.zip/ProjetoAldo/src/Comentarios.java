
public class Comentarios {

    private String comentar;
    private String perfil;
    private int idade;
    private String escolaridade;
    private String email;

    //construtor
    public Comentarios(String comentar, String perfil, int idade, String escolaridade, String email) {
        this.comentar = comentar;
        this.perfil = perfil;
        this.idade = idade;
        this.escolaridade = escolaridade;
        this.email = email;
    }

    // sets e gets
    public String getNome() {
        return comentar;
    }

    public void setNome(String comentar) {
        this.comentar = comentar;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    // metodos
}
