
public class Admin {

    private String perfil;
    private int senha;

    //construtor
    public Admin(String perfil, int senha) {
        this.perfil = perfil;
        this.senha = senha;
    }

    // sets e gets
    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    // metodos
}
