
public class Usuario {

    private String nome;
    private String perfil;
    private int idade;
    private String escolaridade;
    private String email;
    private int senha;

    //construtor
    public Usuario(String nome, String perfil, int idade, String escolaridade, String email, int senha) {
        this.nome = nome;
        this.perfil = perfil;
        this.idade = idade;
        this.escolaridade = escolaridade;
        this.email = email;
        this.senha = senha;
    }

    // sets e gets
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPerfil() {
        return perfil;
    }

    public void setPerfil(String perfil) {
        this.perfil = perfil;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public void setEscolaridade(String escolaridade) {
        this.escolaridade = escolaridade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getSenha() {
        return senha;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }

    // metodos
}
