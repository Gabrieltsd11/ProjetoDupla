
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Principal {

    static Scanner ler = new Scanner(System.in);
    static ArrayList<String> cadastro = new ArrayList<String>();
    static int escolha = 0;

    public static void main(String[] args) {

        do {
            System.out.println("digite 1 para cadastrar\n");
            System.out.println("digite 2 para consultar \n");
            System.out.println("digite 3 para alterar \n");
            System.out.println("digite 4 para remover \n");
            System.out.println("digite 5 para sair do programa");
            escolha = ler.nextInt();
            switch (escolha) {
                case 1:
                    Cadastrar();
                    break;
                case 2:
                    Consultar();
                    break;
                case 3:
                    Alterar();
                    break;
                case 4:
                    Remover();
                    break;
            }
        } while (escolha != 5);
    }

    public static void Cadastrar() {
        Usuario user = new Usuario();  // não está chamando o metodo usuario não sei pq 

        System.out.println("\n[Usuario ]\n");
        System.out.println("Nome:");
        user.setNome(ler.next());
        System.out.println("Perfil:");
        user.setPerfil(ler.next());
        System.out.println("Idade:");
        user.setIdade(ler.nextInt());
        System.out.println("Escolaridade:");
        user.setEscolaridade(ler.next());
        System.out.println("Email:");
        user.setEmail(ler.next());
        System.out.println("Senha:");
        user.setSenha(ler.nextInt());
        

    }

    public static void Consultar() {
        System.out.println("[Usuario]");
        System.out.println("1-Consultar todos\n");
        System.out.println("2-Pesquisar por Perfil");
        int op = ler.nextInt();
        if (op == 1) {
            System.out.println(Arrays.toString(cadastro.toArray()));
        }
        if (op == 2) {
            System.out.println("Digite o número do usuario:");
            int ind = ler.nextInt();
            System.out.println(cadastro.get(ind - 1));
        }
         Usuario user2 = new Usuario(); // não está vindo a outra classe 
        Admin adm = new Admin();
        Comentarios forn2 = new Comentarios();
       
        
        
        System.out.println("\n[Admin]\n");
        System.out.println("perfil:");
        adm.setPerfil(ler.next());
        System.out.println("Senha:");
        adm.setSenha(ler.nextInt());
  
    }

    public static void Alterar() {
        System.out.println("\n[Usuario]\n");
        System.out.println("Número a ser alterado:");
        int Numcadastro = ler.nextInt();
        System.out.println("\n[Novos dados]\n");

        Usuario user1 = new Usuario();  // não sei pq não está importando a classe usuario
       

        System.out.println("\n[Usuario]\n");
        System.out.println("Nome:");
        user1.setNome(ler.next());
        System.out.println("Perfil:");
        user1.setPerfil(ler.next());
        System.out.println("Idade:");
        user1.setIdade(ler.nextInt());
        System.out.println("Escolaridade:");
        user1.setEscolaridade(ler.next());
        System.out.println("Email:");
        user1.setEmail(ler.next());
        System.out.println("Senha:");
        user1.setSenha(ler.nextInt());


        cadastro.remove(Numcadastro - 1);
        cadastro.add(Numcadastro - 1, user1.toString());
    }

    public static void Remover() {
        System.out.println("\n[Usuario]\n");
        System.out.println("Digite o número do usuario:");
        int numcad = ler.nextInt();
        cadastro.remove(numcad - 1);
    }
}
