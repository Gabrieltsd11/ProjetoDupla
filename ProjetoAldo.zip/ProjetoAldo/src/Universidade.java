/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

/**
 *
 * @author GabrielTSD
 */
public class Universidade {

   private String nome;
   private String tipo;
   private  String localizacao;
   
   //construtor

    public Universidade(String nome, String tipo, String localizacao) 
    {
        this.nome = nome;
        this.tipo = tipo;
        this.localizacao = localizacao;
    }
    
    // sets e gets
    
   public String getNome() 
   {
        return nome;
   }

    public void setNome(String nome) 
    {
        this.nome = nome;
    }

    public String getTipo() 
    {
        return tipo;
    }

    public void setTipo(String tipo)
    {
        this.tipo = tipo;
    }

    public String localizacao() 
    {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) 
    {
        this.localizacao = localizacao;
    } 

    // metodos
    
    private String cadastrar;
    /* 
    private set remover;
    private get consultar;
    private get alterar;
    */
     public String imprimir;
    {
            System.out.print(imprimir);
    }
}

